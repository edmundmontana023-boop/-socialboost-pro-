SOCIALBOOST PRO — STARTER WEBSITE

Files
- index.html: responsive single-page website prototype.

Before public launch
1. Replace YOUR BANK NAME, YOUR BUSINESS NAME and 0000000000 with your verified business account details.
2. Replace sample packages with services you can actually deliver. Avoid fake followers, bots, or artificial engagement; use compliant promotion and genuine audience campaigns.
3. This is a front-end prototype only: it does not save orders to a server, send email, or verify payments. Build/attach a secure backend and a supported Nigerian payment gateway/bank transfer verification flow before taking orders.
4. Add real contact details, privacy policy, terms, refund policy, and secure hosting with HTTPS.
5. Never ask customers for social-media passwords or one-time codes.

Open index.html in a browser to preview.
